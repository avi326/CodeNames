<template>
    <div id="guide">
        <h1> Table Of Games </h1>
        <Register/>
    </div>
</template>

<script>
import Register from '@/components/Register'

export default {
    name: 'TableOfGames',
    data () {
        return {

        }
    },
  components: {
    Register
  }
}
</script>

<style>

</style>
