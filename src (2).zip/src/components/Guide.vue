<template>
    <div id="guide">
        <h1> guide </h1>
    </div>
</template>

<script>
export default {
    name: 'Guide',
    data () {
        return {

        }
    }
}
</script>

<style>

</style>
