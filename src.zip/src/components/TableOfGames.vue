<template>
    <div id="guide">
        <h1> Table Of Games </h1>
        <Chat/>
    </div>
</template>

<script>
import Chat from '@/components/Chat'

export default {
    name: 'TableOfGames',
    data () {
        return {

        }
    },
  components: {
    Chat
  }
}
</script>

<style>

</style>
