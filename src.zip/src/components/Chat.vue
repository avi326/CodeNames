<template>
    <div id="chat">
        <div> 
            <b-card>
                <h2> chat </h2>
                <b-form-input v-model="text" placeholder="Enter your name"></b-form-input>
                <div class="mt-2">Value: {{ text }}</div>
            </b-card>
        </div>


    </div>
</template>

<script>
export default {
    name: 'Chat',
    data () {
        return {
        text: ''

        }
    }
}
</script>

<style>

</style>
